# N´hora Burger — Cardápio Digital (Demonstração)

Demonstração criada pela Fely e Amigos | Soluções Digitais.

## O que funciona
- Categorias e pesquisa
- Produtos com preço e descrição
- Carrinho
- Quantidade de itens
- Total automático
- Finalização do pedido pelo WhatsApp
- Layout responsivo para telemóvel e computador
- Carrinho guardado no navegador

## WhatsApp configurado
+244 955 087 238

## Publicar no GitHub Pages
1. Crie um repositório chamado `nhora-burger-menu-demo`.
2. Envie `index.html` para a raiz do repositório.
3. No GitHub: Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
4. Abra o link gerado pelo GitHub Pages.

## Importante
Os produtos, preços e descrições desta primeira versão são exemplos para a demonstração.
Antes de apresentar a versão final ao cliente, substitua-os pelos produtos e preços reais da N´hora Burger.
